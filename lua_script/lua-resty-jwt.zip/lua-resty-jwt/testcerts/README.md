# Test certificates

Those certs have been retrieved from http://fm4dd.com/openssl/certexamples.htm

- Root CA cert: http://fm4dd.com/openssl/source/PEM/certs/frank4dd-cacert.pem
- 2048b RSA cert: http://fm4dd.com/openssl/source/PEM/certs/2048b-rsa-example-cert.pem
- 2048 RSA keypair: http://fm4dd.com/openssl/source/PEM/keys/2048b-rsa-example-keypair.pem
